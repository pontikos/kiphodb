package org.andrewberman.applets;


public class Globals
{
	
	public void destroyGlobals()
	{
		
	}
}
