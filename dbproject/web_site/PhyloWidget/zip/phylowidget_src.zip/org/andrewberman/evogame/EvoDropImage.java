package org.andrewberman.evogame;

import processing.core.PApplet;

public class EvoDropImage extends DragDropImage
{

	public EvoDropImage(PApplet app)
	{
		super(app);
	}

}
